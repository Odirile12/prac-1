#include "ShapeFactory.h"
#include "Canvas.h"

Shape* ShapeFactory::createShape(int length, int width, std::string color, int position_x, int position_y) {
    return nullptr; 

}
Shape* ShapeFactory::createTextbox(int length, int width, std::string color, int position_x, int position_y, std::string text) {
    return nullptr; 
}
void ShapeFactory::toString() {
}