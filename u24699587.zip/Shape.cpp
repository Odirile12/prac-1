#include "Shape.h"


Shape* Shape::clone() {
        return nullptr; 
}
void Shape::print() {
        return;
}
